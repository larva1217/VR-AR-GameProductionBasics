using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CarController : MonoBehaviour
{
    float speed = 0;
    Vector2 startPos;
    AudioSource audio;

    // Start is called before the first frame update
    void Start()
    {
        audio = GetComponent<AudioSource>();
    }

    // Update is called once per frame
    void Update()
    {
        if(Input.GetMouseButtonDown(0)){
           this.startPos=Input.mousePosition;
        }
        else if(Input.GetMouseButtonUp(0)){
            Vector2 endPos=Input.mousePosition;
            float swipeLength = endPos.x - this.startPos.x;

            this.speed = swipeLength/500.0f;

            if(this.speed>0){
                audio.Play();
            }
        }

        transform.Translate(this.speed,0,0);
        this.speed *= 0.98f;
    }

    public void Restart(){
        transform.position = new Vector3(-7,-3.7f,0);
    }
}
