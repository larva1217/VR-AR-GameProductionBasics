using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameDirector : MonoBehaviour
{
    GameObject hpGauge;
    AudioSource ArrowAudio;

    // Start is called before the first frame update
    void Start()
    {
        this.hpGauge=GameObject.Find("hpGauge");
        ArrowAudio = GetComponent<AudioSource>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void DecreaseHP(){
        ArrowAudio.Play();
        this.hpGauge.GetComponent<Image>().fillAmount -= 0.1f;
    }
}
