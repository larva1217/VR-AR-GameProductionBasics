using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NewBehaviourScript : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if(Input.GetKeyDown(KeyCode.LeftArrow)){
            if (transform.position.x > -7)
            {
                transform.Translate(-1, 0, 0);
            }
        }
        if(Input.GetKeyDown(KeyCode.RightArrow)){
            if (transform.position.x < 7)
            {
                transform.Translate(1, 0, 0);
            }
        }
       
    }

    public void LButtonDown(){
        if (transform.position.x > -7)
        {
            transform.Translate(-1, 0, 0);
        }
    }

     public void RButtonDown(){
        if (transform.position.x < 7)
        {
            transform.Translate(1, 0, 0);
        }
    }
}
