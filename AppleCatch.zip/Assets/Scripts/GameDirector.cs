using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class GameDirector : MonoBehaviour
{
    GameObject timeText;
    float time = 30.0f;
    GameObject pointText;
    int point = 0;
    GameObject generator;
    public Button restart;

    public Text bestText;
    int best = 0;

    // Start is called before the first frame update
    void Start()
    {
        this.timeText = GameObject.Find("Time");
        this.pointText = GameObject.Find("Point");
        this.generator = GameObject.Find("ItemGenerator");
    }

    // Update is called once per frame
    void Update()
    {
        this.time -= Time.deltaTime;

        if(this.time < 0)
        {
            this.time = 0;
            this.generator.GetComponent<ItemGenerator>().SetParameter(1000.0f, 0, 0);
            restart.gameObject.SetActive(true);
            int bestScore = PlayerPrefs.GetInt("BestScore");

            if (point > bestScore)
            {
                bestScore = point;
                PlayerPrefs.SetInt("BestScore",bestScore);
            }
            bestText.gameObject.SetActive(true);
            bestText.text = "Best Score : " + bestScore;
        }

        else if(0<=this.time && this.time < 4)
        {
            this.generator.GetComponent<ItemGenerator>().SetParameter(0.3f, -0.06f, 0);
        }
        else if (4 <= this.time && this.time < 12)
        {
            this.generator.GetComponent<ItemGenerator>().SetParameter(0.5f, -0.05f, 6);
        }
        else if (12 <= this.time && this.time < 23)
        {
            this.generator.GetComponent<ItemGenerator>().SetParameter(0.8f, -0.04f, 4);
        }
        else if (23 <= this.time && this.time < 30)
        {
            this.generator.GetComponent<ItemGenerator>().SetParameter(1.0f, -0.03f, 2);
        }

        this.timeText.GetComponent<TextMeshProUGUI>().text = this.time.ToString("F1");
        this.pointText.GetComponent<TextMeshProUGUI>().text = this.point.ToString() + " point";
    }
    
    public void GetApple()
    {
        this.point += 100;
    }

    public void GetBoomb()
    {
        this.point /= 2;
    }
}

