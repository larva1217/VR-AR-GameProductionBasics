using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerController : MonoBehaviour
{

    Rigidbody2D rigid2D;
    Animator anim;
    AudioSource plyerAudio;

    float jumpForce = 680.0f;
    float walkForce = 30.0f;
    float maxwalkSpeed = 2.0f;
    float threshold = 0.2f;

    // Start is called before the first frame update
    void Start()
    {
        this.rigid2D = GetComponent<Rigidbody2D>();
        this.anim = GetComponent<Animator>();
        this.plyerAudio = GetComponent<AudioSource>();
    }

    // Update is called once per frame
    void Update()
    {
        //if (Input.GetKeyDown(KeyCode.Space) && this.rigid2D.velocity.y == 0)
        if(Input.GetMouseButtonDown(0) && this.rigid2D.velocity.y == 0)
        {
            this.rigid2D.AddForce(transform.up * this.jumpForce);
            this.anim.SetTrigger("JumpTrigger");
            plyerAudio.Play();
        }

        int key = 0;
        //if (Input.GetKey(KeyCode.RightArrow)) key = 1;
        //if (Input.GetKey(KeyCode.LeftArrow)) key = -1;
        if (Input.acceleration.x > this.threshold) key = 1;
        if (Input.acceleration.x < -this.threshold) key = -1;

        float speedX = Mathf.Abs(this.rigid2D.velocity.x);

        if (speedX < this.maxwalkSpeed)
        {
            this.rigid2D.AddForce(transform.right * key * this.walkForce);
        }

        if(key != 0)
        {
            transform.localScale = new Vector3(key, 1, 1);
        }

        if (this.rigid2D.velocity.y == 0)
        {
            this.anim.speed = speedX * 0.5f;
        }
        else
        {
            this.anim.speed = 1.0f;
        }

        if(transform.position.y < -10)
        {
            //SceneManager.LoadScene("GameScene");
            transform.position = new Vector3(0, 0, 0);
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        Debug.Log("깃발 충돌");
        SceneManager.LoadScene("ClearScene");

    }
}
