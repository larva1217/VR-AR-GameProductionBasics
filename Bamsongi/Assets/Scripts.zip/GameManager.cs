using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{

    public Text score;
    public Text bestscore;
    public Text totalscore;
    public GameObject restartButton;

    int scoreValue = 0;
    int bestScore = 0;
    int totalScore = 0;
    int count = 0;

    public Terrain ter;

    // Start is called before the first frame update
    void Start()
    {
        bestScore = PlayerPrefs.GetInt("BestScore", 0); 
        bestscore.text = "Best Score: " + (int)bestScore;
    }

    // Update is called once per frame
    void Update()
    {
        score.text = "Score: " + scoreValue;

    }

    public void AddScore(int point)
    {
        scoreValue += point;
    }


    public void EndGame()
    {
     
            totalScore = scoreValue;

            if (totalScore > bestScore)
            {
                bestScore = totalScore;
                PlayerPrefs.SetInt("BestScore", bestScore);
            }


            totalscore.gameObject.SetActive(true);
            totalscore.text = "Total Score: " + (int)totalScore;

            bestscore.gameObject.SetActive(true);
            bestscore.text = "Best Score: " + (int)bestScore;

            restartButton.SetActive(true); 
        
    }

    
    public void Hit(Vector3 bamsongiPosition)
    {
        
        int point = 0;
       
        Vector3 target = new Vector3(0, 6.5f, 0);
        
        float distance = Vector3.Distance(bamsongiPosition, target);
        Debug.Log(distance);

        if (distance <= 9.17f)
        {
            point = 100; 
        }
        else if (distance <= 9.25f)
        {
            point = 80; 
        }
        else if (distance <= 9.2f)
        {
            point = 60; 
        }
        else if (distance <= 9.3f)
        {
            point = 40; 
        }
        else if (distance <= 9.8f)
        {
            point = 20;
        }
        else if (distance <= 9.9f)
        {
            point = 10;
        }
        else
        {
            point = 0; 
        }

        AddScore(point);
    }

    public void RestartGame()
    {
        
        SceneManager.LoadScene("GameScene");
    }
}