using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class PlayerController : MonoBehaviour
{
    Rigidbody rb;
    public float speed = 10f;
    int count;
    float time=0;
    public Text countText;
    public Text TimeText;
    public GameObject WinTextObject;
    public FixedJoystick joystick;
    AudioSource myaudio;

    private void Awake()
    {
        ResetTime();
    }

    // Start is called before the first frame update
    void Start()
    {
        
        rb =GetComponent<Rigidbody>();
        count=0;
        setCountText();
        WinTextObject.SetActive(false);
        myaudio = GetComponent<AudioSource>();
    }


    // Update is called once per frame
    void FixedUpdate()
    {
        time = (int)Time.time;
        TimeText.text = "Time : " + time.ToString();
        //float MoveHorizontal = Input.GetAxis("Horizontal");
        //float moveVertical = Input.GetAxis("Vertical");
        float MoveHorizontal = joystick.Horizontal;
        float moveVertical = joystick.Vertical;

        Vector3 movement = new Vector3(MoveHorizontal,0.0f,moveVertical);

        rb.AddForce(movement*speed);
    }

    void OnTriggerEnter(Collider other){
        if(other.gameObject.CompareTag("PickUp")){
            other.gameObject.SetActive(false);
            count++;
            setCountText();
            myaudio.Play();
        }
    }

    void setCountText(){
        countText.text = "Count : " + count.ToString();
        if(count>=12){
            WinTextObject.SetActive(true);
        }
    }

    public void ResetTime()
    {
        time = 0f; 
        TimeText.text = "Time : 0"; 
    }
}
